<?php $__env->startSection('content'); ?>
<div class="bg-light py-3">
    <div class="container">
    <div class="row">
        <div class="col-md-12 mb-0"><a href="index.html">Home</a> <span class="mx-2 mb-0">/</span> <strong class="text-black">Order</strong></div>
    </div>
    </div>
</div>  

<div class="site-section">
    <div class="container">
    <div class="row">
        <div class="col-md-12 text-center">
        <h2 class="display-3 text-black">Proses Transaksi</h2>

        <br/>
        <br/>
        <div>
        <table class="table site-block-order-table mb-5">
            <thead>
            <h2>Detail Transaksi</h2>
            </thead>
            <tbody>
            <tr>
                <td>Nama: </td>
                <td><?php echo e($name); ?></td>
                <td>Email: </td>
                <td><?php echo e($email); ?></td>
            </tr>
            <tr>
                <td>Invoice: </td>
                <?php $__currentLoopData = $harga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($trans->invoice); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <td>Total Harga: </td>
                <?php $__currentLoopData = $harga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($trans->subtotal); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            </tbody>
        </table>
        </div>
            <p><a href="<?php echo e($url->payment_url); ?>" class="btn btn-sm btn-primary">Bayar Sekarang</a></p>
        </div>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel 7\MyMaster\resources\views/user/order/bayar.blade.php ENDPATH**/ ?>