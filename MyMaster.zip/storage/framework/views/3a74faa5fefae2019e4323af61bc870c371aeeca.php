<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white mr-2">
                  <i class="mdi mdi-home"></i>
                </span> Pesanan </h3>
            </div>
            <div class="row">
              <div class="col-12 grid-margin">
                <div class="card">
                  <div class="card-body">
                    <div class="row mb-3">
                      <div class="col">
                      <h4 class="card-title">Detail Pesanan <?php echo e($order->nama_pelanggan); ?></h4>
                      </div>
                      <div class="col text-right">
                      <a href="javascript:void(0)" onclick="window.history.back()" class="btn btn-primary">Kembali</a>
                      </div>
                    </div>
                    <hr>
                   <div class="row">
                   <div class="col-md-7">
                    <table>
                        <tr>
                            <td>No Invoice</td>
                            <td>:</td>
                            <td  class="p-2"><?php echo e($order->invoice); ?></td>
                        </tr>
                        <?php if($order->metode_pembayaran == 'trf'): ?>
                        <tr>
                            <td>Metode Pembayaran</td>
                            <td>:</td>
                            <td  class="p-2">Transfer</td>
                        </tr>
                        <tr>
                          <td>Status Pesanan</td>
                          <td>:</td>
                          <td  class="p-2"><?php echo e($order->status); ?></td>
                        </tr>
                        <tr>
                            <td>Total</td>
                            <td>:</td>
                            <td  class="p-2">Rp. <?php echo e(number_format($order->subtotal,2,',','.')); ?></td>
                        </tr>
                        <tr>
                            <td>No Hp</td>
                            <td>:</td>
                            <td  class="p-2"><?php echo e($order->no_hp); ?></td>
                        </tr>
                        <tr>
                            <td>Alamat Pelanggan</td>
                            <td>:</td>
                            <td  class="p-2"><?php echo e($order->alamatlengkap); ?></td>
                        </tr>
                        <?php if($order->status_order_id == 2): ?>
                          <?php if($payment->status == 'success'): ?>
                          <tr>
                            <td>Tipe Pembayaran</td>
                            <td>:</td>
                            <td  class="p-2"><?php echo e($payment->payment_type); ?></td>
                          </tr>
                          <tr>
                            <td>Token Pembayaran</td>
                            <td>:</td>
                            <td  class="p-2"><?php echo e($payment->token); ?></td>
                          </tr>
                          <tr>
                              <td></td>
                              <td></td>
                              <td  class="p-2"><a href="<?php echo e(route('admin.transaksi.konfirmasitrf',['id' => $order->id])); ?>" onclick="return confirm('Yakin ingin mengonfirmasi pesanan ini?')" class="btn btn-primary mt-1">Konfirmasi Telah Bayar</a><br>
                              <small>Klik tombol jika pembeli sudah melakukan pembayaran</small>
                              </td>
                          </tr>
                          <?php endif; ?>
                        <?php endif; ?>
                        <?php if($order->status_order_id == 3): ?>
                          <tr>
                              <td></td>
                              <td></td>
                              <td  class="p-2"><a href="<?php echo e(route('admin.transaksi.kirim',['id' => $order->id])); ?>" onclick="return confirm('Yakin ingin mengonfirmasi pesanan ini?')" class="btn btn-primary mt-1">Konfirmasi Pengiriman</a><br>
                              <small>Klik tombol jika status barang telah dikirim</small>
                              </td>
                          </tr>
                        <?php endif; ?>
                        <?php endif; ?>


                        <?php if($order->metode_pembayaran == 'byr'): ?>
                        <tr>
                            <td>Metode Pembayaran</td>
                            <td>:</td>
                            <td  class="p-2">Bayar Ditoko</td>
                        </tr>
                        <tr>
                          <td>Status Pesanan</td>
                          <td>:</td>
                          <td  class="p-2"><?php echo e($order->status); ?></td>
                        </tr>
                        <tr>
                            <td>Total</td>
                            <td>:</td>
                            <td  class="p-2">Rp. <?php echo e(number_format($order->subtotal,2,',','.')); ?></td>
                        </tr>
                        <tr>
                            <td>No Hp</td>
                            <td>:</td>
                            <td  class="p-2"><?php echo e($order->no_hp); ?></td>
                        </tr>
                        <tr>
                            <td>Alamat Pelanggan</td>
                            <td>:</td>
                            <td  class="p-2"><?php echo e($order->alamatlengkap); ?></td>
                        </tr>
                        <?php if($order->status_order_id == 1): ?>
                          <tr>
                            <td></td>
                            <td></td>
                            <td  class="p-2"><a href="<?php echo e(route('admin.transaksi.konfirmasibyr',['id' => $order->id])); ?>" onclick="return confirm('Yakin ingin mengonfirmasi pesanan ini?')" class="btn btn-primary mt-1">Konfirmasi Pembayaran</a><br>
                            <small>Klik tombol jika pembeli sudah melakukan pembayaran di toko</small>
                            </td>
                          </tr>
                        <?php endif; ?>
                        <?php endif; ?>
                        
                    </table>
                    </div>
                    <div class="col-md-5">
                    <div class="table-responsive">
                      <table class="table table-bordered table-hovered" >
                        <thead class="bg-primary text-white">
                          <tr>
                            <th width="5%">No</th>
                            <th>Nama Produk</th>
                            <th>QTY</th>
                            <th>Total Harga</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php $no=1;?>
                            <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($dt->nama_produk); ?></td>
                                <td><?php echo e($dt->qty); ?></td>
                                <td><?php echo e($dt->qty * $dt->price); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                    </div>
                   </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KP_Ahoy\MyMaster\resources\views/admin/transaksi/detail.blade.php ENDPATH**/ ?>