<?php $__env->startSection('content'); ?>
<div class="site-section block-3 site-blocks-2 bg-light"  data-aos="fade-up">
    <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-7 site-section-heading text-center pt-4">
        <h2>Daftar Produk</h2>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
        <div class="nonloop-block-3 owl-carousel" >
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
            <div class="block-4 text-center">
                <a href="<?php echo e(route('user.produk.detail',['id' =>  $products->id])); ?>">
                <figure class="block-4-image">
                <img src="<?php echo e(asset('storage/'.$products->image)); ?>" alt="Image placeholder" class="img-fluid" width="100%" style="height:300px">
                </figure>
                </a>
                <div class="block-4-text p-4">
                <h3><a href="<?php echo e(route('user.produk.detail',['id' =>  $products->id])); ?>"><?php echo e($products->name); ?></a></h3>
                <p class="mb-0"><?php echo e($products->price); ?></p>
                <a href="<?php echo e(route('user.produk.detail',['id' =>  $products->id])); ?>" class="btn btn-primary mt-2">Detail</a>
                </div>
            </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </div>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel 7\MyMaster\resources\views/user/welcome.blade.php ENDPATH**/ ?>